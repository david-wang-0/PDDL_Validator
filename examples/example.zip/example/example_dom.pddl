(define 
    (domain Example)
    (:requirements :object-fluents)

   
    (:predicates
        (p)
    )

    (:functions
        (f ?obj) - object
    )

    ;; Move the robot ?r from the location ?from to the location ?to while
    ;; consuming the battery
    (:action do
        :parameters (?obj)
        :precondition (= (f ?obj) (f ?obj))
        :effect (p)
    )
)